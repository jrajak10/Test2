$(document).ready(function() {
  var input;
  var result;
  
  $("#Calculate").click(function() {
    input = $("#candy").val();
    result = evolutions(input);
    $("#answer").text(result);
  });
  
});



function evolutions(candy){
  
   if (candy < 144){
     return "You can evolve " + Math.floor(candy/12) + " Pokemon";
    }
   else if (candy >= 144 && candy < 1728){
     return "You can evolve " + (Math.floor(candy/144) + Math.floor(candy/12)) + " Pokemon";
   }   
   else if (candy >= 1728 && candy < 16535){   
   return "You can evolve " + (Math.floor(candy/1728) + Math.floor(candy/144) + Math.floor(candy/12)) + " Pokemon";
   }
      else {
        return "Your number exceeds the maximum Pokemon Limit";
      }
     
  
}